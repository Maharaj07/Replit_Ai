package com.sdk.example;

import java.util.ArrayList;
import java.util.Iterator;

public class ConclusionUtils {
	public static String[] chinese = { "停搏", "室颤/室速", "R ON T", "三个或四个连发室早", "二连发室早", "单个室早",
			"室早二连律", "室早三联律", "室上行心动过速", "心动过缓", "起搏器未俘获", "起搏器未起搏", "漏搏",
			"正在学习", "正常心率", "噪声信号", "预留", "预留", "预留", "预留", "未见异常", "窦性心动过缓",
			"窦性心动过速", "WPW预激综合症", "(A型)", "(B型)", "左心房肥大", "右心房肥大", "双房肥大",
			"QRS低电压", "肺部疾病心电类型", "电轴正常", "电轴左偏", "电轴右偏", "心电轴重度左偏", "心电轴轻度右偏",
			"心电轴中度右偏", "心电轴重度右偏", "完全右束支阻滞", "完全左束支阻滞", "不完全性右束支阻滞",
			"不完全性左束支阻滞", "V1呈RSR'型", "左前分支阻滞", "左后分支阻滞", "左室肥大", "右室肥大",
			"一度房室传导阻滞", "预留", "预留", "预留", "前间壁心梗早期", "可疑前间壁心梗早期", "前间壁心梗可能急性期",
			"可疑前间壁心梗可能急性期", "前间壁心梗陈旧期", "可疑前间壁心梗陈旧期", "前壁心梗早期", "可疑前壁心梗早期",
			"前壁心梗可能急性期", "可疑前壁心梗可能急性期", "前壁心梗陈旧期", "可疑前壁心梗陈旧期", "广泛前壁心梗早期",
			"可疑广泛前壁心梗早期", "广泛前壁心梗可能急性期", "可疑广泛前壁心梗可能急性期", "广泛前壁心梗陈旧期",
			"可疑广泛前壁心梗陈旧期", "心尖部心梗早期", "心尖部心梗可能急性期", "心尖部心梗陈旧期", "前侧壁心梗早期",
			"可疑前侧壁心梗早期", "前侧壁心梗可能急性期", "可疑前侧壁心梗可能急性期", "前侧壁心梗陈旧期",
			"可疑前侧壁心梗陈旧期", "高侧壁心梗早期", "高侧壁心梗可能急性期", "高侧壁心梗陈旧期", "下壁心梗早期",
			"可疑下壁心梗早期", "下壁心梗可能急性期", "可疑下壁心梗可能急性期", "下壁心梗陈旧期", "可疑下壁心梗陈旧期",
			"下侧壁心梗早期", "可疑下侧壁心梗早期", "下侧壁心梗可能急性期", "可疑下侧壁心梗可能急性期", "下侧壁心梗陈旧期",
			"可疑下侧壁心梗陈旧期", "ST压低，前间壁轻度心肌缺血", "ST压低，可疑前间壁轻度心肌缺血",
			"ST压低，前壁轻度心肌缺血", "ST压低，可疑前壁轻度心肌缺血", "ST压低，广泛前壁轻度心肌缺血",
			"ST压低，可疑广泛前壁轻度心肌缺血", "ST压低，心尖部轻度心肌缺血", "ST压低，可疑心尖部轻度心肌缺血",
			"ST压低，前侧壁轻度心肌缺血", "ST压低，可疑前侧壁轻度心肌缺血", "ST压低，高侧壁轻度心肌缺血",
			"ST压低，下壁轻度心肌缺血", "ST压低，可疑下壁轻度心肌缺血", "ST压低，下侧壁轻度心肌缺血",
			"ST压低，可疑下侧壁轻度心肌缺血", "ST压低，前间壁心肌缺血", "ST压低，可疑前间壁心肌缺血",
			"ST压低，前壁心肌缺血", "ST压低，可疑前壁心肌缺血", "ST压低，广泛前壁心肌缺血", "ST压低，可疑广泛前壁心肌缺血",
			"ST压低，心尖部心肌缺血", "ST压低，可疑心尖部心肌缺血", "ST压低，前侧壁心肌缺血", "ST压低，可疑前侧壁心肌缺血",
			"ST压低，高侧壁心肌缺血", "ST压低，下壁心肌缺血", "ST压低，可疑下壁心肌缺血", "ST压低，下侧壁心肌缺血",
			"ST压低，可疑下侧壁心肌缺血", "I", "II", "III", "aVR", "aVL", "aVF", "V1",
			"V2", "V3", "V4", "V5", "V6", "T波异常" };

	public static String[] english = {
			"ASY",
			"VF/VTA",
			"RONT",
			"RUN",
			"CPT",
			"VPB",
			"BGM",
			"TGM",
			"TAC",
			"BRD",
			"PNC",
			"PNP",
			"MIS",
			"LRN",
			"NML",
			"NOS",
			";",
			";",
			";",
			";",
			"No abnormalities",
			"Sinus mode Bradycardia",
			"Sinus mode Tachycardia",
			"WPW Preexcitation syndrome",
			"(A type)",
			"(B type)",
			"left atrium Hypertrophy",
			"right atrium Hypertrophy",
			"double atrium Hypertrophy",
			"QRS low voltage",
			"pulmonary disease (ECG style)",
			"Cardiac electric axis normal",
			"Left axis deviation",
			"Right axis deviation",
			"Severity Left axis deviation",
			"Longitudinal Right axis deviation",
			"Middling Right axis deviation",
			"Severity Right axis deviation",
			"Completeness Right Bundle branch block",
			"Completeness Left Bundle branch block",
			"No Completeness Right Bundle branch block",
			"No Completeness Left Bundle branch block",
			"V1 Present RSR'Type",
			"Left and Front Fascicles Conduction block",
			"Left and Back Fascicles Conduction block",
			"Left ventricle Hypertrophy",
			"Right ventricle Hypertrophy",
			"I AV block",
			";",
			";",
			";",
			"forepart anteroseptal MI",
			"possible forepart anteroseptal MI",
			"accute forepart anteroseptal MI",
			"possible accute forepart anteroseptal MI",
			"old anteroseptal MI",
			"possible old anteroseptal MI",
			"forepart anterior MI",
			"possible forepart anterior MI",
			"accute anterior MI",
			"possible accute anterior MI",
			"old anterior MI",
			"possible old anterior MI",
			"forepart extensive anterior MI",
			"possible forepart extensive anterior MI",
			"accute extensive anterior MI",
			"possible accute extensive anterior MI",
			"old extensive anterior MI",
			"possible old extensive anterior MI",
			"forepart opical MI",
			"accute opical MI",
			"old opical MI",
			"forepart anterolateral MI",
			"possible forepart anterolateral MI",
			"accute anterolateral MI",
			"possible accute anterolateral MI",
			"old anterolateral MI",
			"possible old anterolateral MI",
			"forepart high lateral MI",
			"accute high lateral MI",
			"old high lateral MI",
			"forepart inferior MI",
			"possible forepart inferior MI",
			"accute inferior MI",
			"possible accute inferior MI",
			"old inferior MI",
			"possible old inferior MI",
			"forepart inferolateral MI",
			"possible forepart inferolateral MI",
			"accute inferolateral MI",
			"possible accute inferolateral MI",
			"old inferolateral MI",
			"possible old inferolateral MI",
			"ST depression, mild anteroseptal myocardial ischemia",
			"ST depression, possible mild anteroseptal myocardial ischemia",
			"ST depression, mild anterior myocardial ischemia",
			"ST depression, possible mild anterior myocardial ischemia",
			"ST depression, mild extensive anterior myocardial ischemia",
			"ST depression, possible mild extensive anterior myocardial ischemia",
			"ST depression, mild opical myocardial ischemia",
			"ST depression, possible mild opical myocardial ischemia",
			"ST depression, mild anterolateral myocardial ischemia",
			"ST depression, possible mild anterolateral myocardial ischemia",
			"ST depression, mild high lateral myocardial ischemia",
			"ST depression, mild inferior myocardial ischemia",
			"ST depression, possible mild inferior myocardial ischemia",
			"ST depression, mild inferolateral myocardial ischemia",
			"ST depression, possible mild inferolateral myocardial ischemia",
			"ST depression, anteroseptal Myocardial ischemia",
			"ST depression, possible anteroseptal Myocardial ischemia",
			"ST depression, anterior Myocardial ischemia",
			"ST depression, possible anterior Myocardial ischemia",
			"ST depression, extensive anterior Myocardial ischemia",
			"ST depression, possible extensive anterior Myocardial ischemia",
			"ST depression, opical myocardial ischemia",
			"ST depression, possible opical myocardial ischemia",
			"ST depression, anterolateral Myocardial ischemia",
			"ST depression, possible anterolateral Myocardial ischemia",
			"ST depression, high lateral myocardial ischemia",
			"ST depression, inferior Myocardial ischemia",
			"ST depression, possible inferior Myocardial ischemia",
			"ST depression, inferolateral Myocardial ischemia",
			"ST depression, possible inferolateral Myocardial ischemia", "I",
			"II", "III", "aVR", "aVL", "aVF", "V1", "V2", "V3", "V4", "V5",
			"V6", "Abnormal T wave" };


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private ArrayList<Short> getSingle(ArrayList<Short> list) {
		ArrayList newList = new ArrayList<Short>(); // 创建新集合
		Iterator it = list.iterator(); // 根据传入的集合(旧集合)获取迭代器
		while (it.hasNext()) { // 遍历老集合
			Object obj = it.next(); // 记录每一个元素
			if (!newList.contains(obj)) { // 如果新集合中不包含旧集合中的元素
				newList.add(obj); // 将元素添加
			}
		}
		return newList;
	}

	public ArrayList<Short> combineConclusion(ArrayList<Short> realtime,
			ArrayList<Short> statics) {
		
		ArrayList<Short> result = new ArrayList<Short>();
		ArrayList<Short> a = getSingle(realtime);
		ArrayList<Short> b = getSingle(statics);

		for (int i = 0; i < a.size(); i++) {
			Short x = a.get(i);
			//排除 "正在学习", "正常心率", "噪声信号"三种异常
			if ((x != 13) && (x != 14) && (x != 15)) {
				result.add(x);
			}
		}
		for (int j = 0; j < b.size(); j++) {
			result.add(b.get(j));
		}

		if (result.contains(21) || result.contains(22)) {

			for (int k = 0; k < result.size(); k++) {
				if ((result.get(k) == 8) || (result.get(k) == 9)) {
					result.remove(k);
				}
			}
		}

		if (result.size() >= 2) {

			if (result.contains(20)) {
				for (int k = 0; k < result.size(); k++) {
					if (result.get(k) == 20) {
						result.remove(k);
					}
				}
			}
		}
		
		return result;
	}
}
