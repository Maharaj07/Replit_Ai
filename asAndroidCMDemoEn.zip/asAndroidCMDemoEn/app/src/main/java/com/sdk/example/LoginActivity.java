package com.sdk.example;


import com.sdk.example.InputMethodRelativeLayout.OnSizeChangedListenner;
import com.contec.jni.IDCardInfo;
import com.contec.jni.IDCardInterface;
import com.contec.jni.IDCardMsg;
import com.contec.jni.SerialPort;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class LoginActivity extends Activity implements OnSizeChangedListenner {
    private InputMethodRelativeLayout layout;
    private LinearLayout boot;
    private LinearLayout login_logo_layout_h;
    private LinearLayout login_logo_layout_v;
    private Button loginBtn;
    private EditText userText;
    private SerialPort serial ;
    private Button regBtn;
    private ImageView logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        userText = (EditText) findViewById(R.id.qqId);
        loginBtn = (Button) findViewById(R.id.login_btn);
        logo = (ImageView) findViewById(R.id.login_logoimg);
        serial = MyApplication.getInstance().getSerialPort();
        serial.openIDCard(new IDCardMsg(new IDCardDisplay()));
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serial.closeIDCard();
                Intent intent = new Intent(LoginActivity.this, WaveActivity.class);
                startActivity(intent);
                finish();
            }
        });
        regBtn = (Button) findViewById(R.id.reg_tv);
        regBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                serial.closeIDCard();
                Intent intent = new Intent(LoginActivity.this, OtherIDActivity.class);
                startActivity(intent);
                finish();
            }
        });

        layout = (InputMethodRelativeLayout) this.findViewById(R.id.loginpage);

        layout.setOnSizeChangedListenner(this);

        login_logo_layout_v = (LinearLayout) this.findViewById(R.id.login_logo_layout_v);

        login_logo_layout_h = (LinearLayout) this.findViewById(R.id.login_logo_layout_h);


        boot = (LinearLayout) this.findViewById(R.id.reg_and_forget_password_layout);

    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        appExit();
    }

    @Override
    public void onSizeChange(boolean flag, int w, int h) {
        if (flag) {
            layout.setPadding(0, -10, 0, 0);
            boot.setVisibility(View.GONE);
            login_logo_layout_v.setVisibility(View.GONE);
            login_logo_layout_h.setVisibility(View.VISIBLE);
        } else {
            layout.setPadding(0, 0, 0, 0);
            boot.setVisibility(View.VISIBLE);
            login_logo_layout_v.setVisibility(View.VISIBLE);
            login_logo_layout_h.setVisibility(View.GONE);
        }
    }

    private static final int MESSAGE_UPDATE_IDCARDINFO = 5;

    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_UPDATE_IDCARDINFO:
                    userText.setText(((IDCardInfo) msg.obj).getIDCardNo());
                    Bitmap bmp = ((IDCardInfo) msg.obj).getUserImgBmp();
                    logo.setImageBitmap(bmp);
                default:
                    break;
            }
        }

    };

    private class IDCardDisplay implements IDCardInterface {

        @Override
        public void callIDCardMsg(IDCardInfo sTmp) {
            mHandler.obtainMessage(MESSAGE_UPDATE_IDCARDINFO, sTmp)
                    .sendToTarget();
        }

    }


    private long clickTime = 0;

    private void appExit() {
        if ((System.currentTimeMillis() - clickTime) > 2000) {
            Toast.makeText(getApplicationContext(), "Press again to exit!",
                    Toast.LENGTH_SHORT).show();
            clickTime = System.currentTimeMillis();
            return;
        } else {
            finish();
            System.exit(0);
        }
    }
}
