package com.sdk.example;

import android.app.Application;

import com.contec.jni.SerialPort;

public class MyApplication extends Application {
    private static MyApplication instance;
    private SerialPort serial;

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();
        instance = this;

    }

    public static MyApplication getInstance() {

        return instance;
    }


    public MyApplication() {
        serial = new SerialPort();
    }


    public SerialPort getSerialPort() {
        return serial;
    }
}
