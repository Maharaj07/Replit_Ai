package com.sdk.example;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.contec.jni.IDCardInfo;
import com.contec.jni.IDCardInterface;
import com.contec.jni.IDCardMsg;
import com.contec.jni.SerialPort;

import com.sjl.idcard.IdentityCardHandler;
import com.sjl.idcard.entity.IdentityCard;
import com.sjl.idcard.listener.CompoundListener;
import com.sjl.idcard.util.BitmapUtils;
import com.sjl.idcard.util.ByteUtils;

public class OtherIDActivity extends Activity {
    private SerialPort serial ;
    TextView tv_info;
    ImageView img_info;
    Button btn_rfid;
    private Bitmap bitmap;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.other_idinfo);
        tv_info = (TextView) findViewById(R.id.tv_info);
        btn_rfid = (Button) findViewById(R.id.btn_rfid);
        img_info = (ImageView) findViewById(R.id.img_info);
        serial = MyApplication.getInstance().getSerialPort();
        btn_rfid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readRFID();
                btn_rfid.setEnabled(false);
            }
        });
        identityCardHandler = IdentityCardHandler.getInstance(this);
    }
    private final int MESSAGE_UPDATE_ID_MSG = 0x005;

    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_UPDATE_ID_MSG:
                    tv_info.setText(msg.obj.toString());
                    if(bitmap != null){
//                        img_info.setImageBitmap(bitmap);
                        bitmap = null;
                    }
                    btn_rfid.setEnabled(true);
                default:
                    break;
            }
        }

    };
    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (KeyEvent.KEYCODE_BACK == keyCode) {
//            serial.closeIDCard();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }

    private void readRFID(){
        serial.openIDCard(new IDCardMsg(new IDCardDisplay()));
    }

    private class IDCardDisplay implements IDCardInterface {

        @Override
        public void callIDCardMsg(IDCardInfo sTmp) {
            final String tmp = "姓名：" + sTmp.getName() + "\n" + "性别："
                    + sTmp.getSex() + "     " + "民族：" + sTmp.getNation()
                    + "\n" + "出生：" + sTmp.getBirthday().substring(0, 4) + "年"
                    + sTmp.getBirthday().substring(4, 6) + "月"
                    + sTmp.getBirthday().substring(6, 8) + "日" + "\n" + "住址："
                    + sTmp.getAddress() + "\n" + "公民身份证号："
                    + sTmp.getIDCardNo() + "\n" + "签发机关："
                    + sTmp.getGrantDept() + "\n" + "有效期："
                    + sTmp.getUserLifeBegin().substring(0, 4) + "."
                    + sTmp.getUserLifeBegin().substring(4, 6) + "."
                    + sTmp.getUserLifeBegin().substring(6, 8) + "-"
                    + sTmp.getUserLifeEnd().substring(0, 4) + "."
                    + sTmp.getUserLifeEnd().substring(4, 6) + "."
                    + sTmp.getUserLifeEnd().subSequence(6, 8);
            Log.e("IDCARD", tmp);

//            bitmap = sTmp.getUserImgBmp();
//            mHandler.obtainMessage(MESSAGE_UPDATE_ID_MSG, tmp)
//                    .sendToTarget();

            IdentityCard identityCard = new IdentityCard(sTmp.getName(), sTmp.getSex(), sTmp.getNation(), sTmp.getBirthday(), sTmp.getAddress(), sTmp.getIDCardNo(),
                    sTmp.getGrantDept(), sTmp.getUserLifeBegin() + sTmp.getUserLifeEnd(), sTmp.getUserImgBmp());

            identityCardHandler.compound(true,identityCard, new CompoundListener() {
                @Override
                public void onStart() {
                    Log.e("OtherODActivity", "合成开始");
                }

                @Override
                public void onSuccess(IdentityCard identityCard) {
//                    bitmap = identityCard.getFrontBitmap();
                    bitmap = identityCard.getFullBitmap();

                    img_info.setImageBitmap(BitmapUtils.scaleBitmap(bitmap, 1.2f));
                    mHandler.obtainMessage(MESSAGE_UPDATE_ID_MSG, tmp)
                            .sendToTarget();
                }

                @Override
                public void onFailed(Throwable t) {
                    Log.e("OtherODActivity", "身份证合成失败", t);
                }
            });
            serial.closeIDCard();//点击单次刷卡
        }

    }
    private IdentityCardHandler identityCardHandler;
}
