package com.sdk.example;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.contec.jni.CallBackInterface;
import com.contec.jni.CallBackMsg;
import com.contec.jni.SerialPort;
import com.contec.opengl.DrawUtils;
import com.contec.opengl.GLView;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class WaveActivity extends Activity {
    private SerialPort serial = new SerialPort();
    private GLView glView;
    private Button btn_measure;
    private Button btn_save;
    private Button btn_analyze;

    private Button btn_ac;
    private Button btn_emg;
    private Button btn_dft;
    private Button btn_nbp_cal;
    private Button btn_ecg_cal;
    private Button btn_ecg_pace;

    private TextView hrTextView;
    private TextView nbpTextView;
    private TextView leadInfoTextView;
    private TextView tempTextView;
    private TextView spo2TextView;
    private TextView bgTextView;
    private TextView hwTextView;

    private boolean IsMeasure;
    private boolean IsSave;

    private boolean isAC;
    private boolean isEMG;
    private boolean isDFT;
    private boolean isNbpCal;
    private boolean isEcgCal;
    private boolean isEcgPace;

    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setContentView(R.layout.wave);
        } else if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            setContentView(R.layout.wave_port);
        }
        mContext = this;
        glView = (GLView) findViewById(R.id.GLWave);
        glView.setZOrderOnTop(true);
        glView.getHolder().setFormat(PixelFormat.TRANSLUCENT);
        serial = MyApplication.getInstance().getSerialPort();
        serial.setCMType(false);
        type = serial.getCMType();
        if (type == 1) {//7 lead
            CHAN = 7;
        }
        glView.initDisplay(type);
        CallBackMsg jniMsg = new CallBackMsg(new tMsg());
        serial.open(jniMsg);
		DrawUtils.setDisplayMode(0);
        hrTextView = (TextView) findViewById(R.id.hr_value);
        nbpTextView = (TextView) findViewById(R.id.nbp_value);
        leadInfoTextView = (TextView) findViewById(R.id.lead_info);
        spo2TextView = (TextView) findViewById(R.id.spo2);
        tempTextView = (TextView) findViewById(R.id.temp_value);
        bgTextView = (TextView) findViewById(R.id.bg_value);
        hwTextView = (TextView) findViewById(R.id.hw_value);

        btn_measure = (Button) findViewById(R.id.nbp_button);
        btn_save = (Button) findViewById(R.id.save_button);
        btn_analyze = (Button) findViewById(R.id.analyze_button);

        btn_ac = (Button) findViewById(R.id.ac_button);
        btn_emg = (Button) findViewById(R.id.emg_button);
        btn_dft = (Button) findViewById(R.id.dft_button);
        btn_nbp_cal = (Button) findViewById(R.id.nbp_cal_button);
        btn_ecg_cal = (Button) findViewById(R.id.ecg_cal_button);
        btn_ecg_pace = (Button) findViewById(R.id.pace_button);

        IsMeasure = true;
        IsSave = true;
        isNbpCal = true;
        //Turn blood pressure measurement on or off
        btn_measure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (IsMeasure) {
                    btn_measure.setText("stop");
                    serial.startNBP();
                    serial.setSpo2Sense((char) 1);
                } else {
                    btn_measure.setText("measure");
                    serial.stopNBP();
                    nbpTextView.setText("---/---/---");
                }
                IsMeasure = !IsMeasure;
            }
        });
        //Start or cancel ECG storage
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (IsSave) {
                    btn_save.setText("stop");
                    // save file
                    serial.saveCase(Environment.getExternalStorageDirectory()
                            + "/", "data.ecg", timeLength);
                } else {
                    btn_save.setText("store");
                    // cancel save file
                    serial.cancelCase();
                }
                IsSave = !IsSave;
            }
        });
        //ECG data analysis, to ensure that ECG data files exist, and then call this method.
        btn_analyze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serial.ecgAnalyze(Environment.getExternalStorageDirectory()
                        + "/", "data", 0);
            }
        });
        //AC filter
        btn_ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isAC) {
                    btn_ac.setText("AC off");

                } else {
                    btn_ac.setText("AC on");
                }
                isAC = !isAC;
                serial.setAcFilter(isAC);
            }
        });
        //EMG filter
        btn_emg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEMG) {
                    btn_emg.setText("EMG off");

                } else {
                    btn_emg.setText("EMG on");
                }
                isEMG = !isEMG;
                serial.setEmgFilter(isEMG);
            }
        });
        //DFT filter
        btn_dft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isDFT) {
                    btn_dft.setText("DFT off");

                } else {
                    btn_dft.setText("DFT on");
                }
                isDFT = !isDFT;
                serial.setDFTFilter(isDFT);
            }
        });
        btn_ecg_pace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEcgPace) {
                    btn_ecg_pace.setText("Pace off");

                } else {
                    btn_ecg_pace.setText("Pace on");
                }
                isEcgPace = !isEcgPace;
                serial.setEcgPace(isEcgPace);
            }
        });
        //Blood pressure calibration
        btn_nbp_cal.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (isNbpCal) {
                    btn_nbp_cal.setText("stop calibrate");
                    serial.startCAL();
                } else {
                    btn_nbp_cal.setText("start calibrate");
                    serial.stopNBP();
                    nbpTextView.setText("---/---/---");
                }
                isNbpCal = !isNbpCal;
            }
        });


        btn_ecg_cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEcgCal) {
                    btn_ecg_cal.setText("SquareWave off");

                } else {
                    btn_ecg_cal.setText("SquareWave on");
                }
                isEcgCal = !isEcgCal;
                serial.ecgCalibration(isEcgCal);
            }
        });

        //Initialize filter mode
        serial.setFilterMode((char) 1);

        //Initialize filter selection
        serial.setAcFilter(isAC);
        serial.setEmgFilter(isEMG);
        serial.setDFTFilter(isDFT);
        serial.setEcgPace(isEcgPace);
        nbpErrs = getResources().getStringArray(R.array.measure_nbp_err);
		InitSpO2StrIndex = 0;
		isFingerOut = false;
    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        mEcgQueue = new ConcurrentLinkedQueue<>();
        glView.setEcgDataBuf(mEcgQueue);
        glView.onResume();
        glView.visibleRenderer();
    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        glView.onPause();
        glView.goneRenderer();
        if (mEcgQueue != null) {
            mEcgQueue.clear();
            mEcgQueue = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        serial.stopNBP();
        serial.close();
        // 移除所有的handler 消息.
        mHandler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private short[] nbp_result = {-1, -1, -1};
    private static final int MESSAGE_UPDATE_HR = 0;
    private static final int MESSAGE_UPDATE_LeadOff = 1;
    private static final int MESSAGE_UPDATE_CUFPRE = 2;
    private static final int MESSAGE_UPDATE_NBPRESULT = 3;
    private static final int MESSAGE_UPDATE_TEMP = 4;
    private static final int MESSAGE_UPDATE_SPO2 = 5;
    private static final int MESSAGE_UPDATE_BG = 6;
    private static final int MESSAGE_UPDATE_NBPRESULT2 = 7;
    private static final int MESSAGE_UPDATE_ECG_RATE = 8;
	private static final int MESSAGE_UPDATE_HW = 9;
    private static final int MESSAGE_UPDATE_NBPEND = 16;
    private static final int MESSAGE_UPDATE_NBPERR = 17;
    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_UPDATE_HR:
                    hrTextView.setText(msg.obj.toString());
                    break;
                case MESSAGE_UPDATE_CUFPRE:
                    nbpTextView.setText(msg.obj.toString());
                    break;
                case MESSAGE_UPDATE_NBPRESULT:
                    nbpTextView.setText("" + nbp_result[0] + "/" + nbp_result[1]
                            + "/" + nbp_result[2]);
                    btn_measure.setText("measure");
                    IsMeasure = true;
                    break;
                case MESSAGE_UPDATE_LeadOff:
                    leadInfoTextView.setText(msg.obj.toString());
                    break;
                case MESSAGE_UPDATE_TEMP:
                    tempTextView.setText("" + msg.obj);
                    break;
                case MESSAGE_UPDATE_SPO2:
//				spo2TextView.setText(msg.obj.toString());
				if (isFingerOut) {
					spo2TextView.setText("--/--");
					InitSpO2StrIndex = 0;
				} else if (msg.obj.toString().equals("--/--")) {// 2015-04-07
					spo2TextView.setText(InitStr[InitSpO2StrIndex]);
					InitSpO2StrIndex++;
					InitSpO2StrIndex = InitSpO2StrIndex % (InitStr.length);
				} else {
					spo2TextView.setText(msg.obj.toString());
				}
                    break;
                case MESSAGE_UPDATE_BG:
                    bgTextView.setText(msg.obj.toString());
                    break;
                case MESSAGE_UPDATE_NBPRESULT2:

                    break;
                case MESSAGE_UPDATE_ECG_RATE:
                    short rate = (Short) msg.obj;
                    Toast.makeText(mContext, "stored " + rate + " s data！",
                            Toast.LENGTH_SHORT).show();

                    if (rate == timeLength) {
                        btn_save.setText("store");
                        IsSave = !IsSave;
                    }
                    break;
				case MESSAGE_UPDATE_HW:
                    String[] hw = (String[]) msg.obj;
                    String height;
                    String weight;
                    if ("0".equals(hw[1].substring(0, 1))) {
                        height = hw[1].substring(1);
                    } else {
                        height = hw[1];
                    }
                    if ("0".equals(hw[0].substring(0, 1))) {
                        weight = hw[0].substring(1);
                    } else {
                        weight = hw[0];
                    }
                    hwTextView.setText(height + "/" + weight);	
                case MESSAGE_UPDATE_NBPEND:

                    btn_measure.setText("measure");
                    Toast.makeText(WaveActivity.this, "end" + (Short) msg.obj,
                            Toast.LENGTH_LONG).show();
                    if (10 == (Short) (msg.obj)) {
                        nbpTextView.setText("ERR");
                    }
                    IsMeasure = true;
                    break;
                case MESSAGE_UPDATE_NBPERR:
                    nbpTextView.setText("--/--/--");
                    Toast.makeText(WaveActivity.this, (String) msg.obj,
                            Toast.LENGTH_LONG).show();
                    btn_measure.setText("measure");
                    IsMeasure = true;
                    break;
                default:
                    break;
            }
        }

    };

    private ArrayList<Short> real = new ArrayList<Short>();
	private boolean isFingerOut;
	public int InitSpO2StrIndex;
//	public final String InitStr[] = { " ", "--/--" };
    public final String InitStr[] = { " ", "-", " ", "--", " ", "--/" , " ", "--/-", " ", "--/--"};
    private class tMsg implements CallBackInterface {

        @Override
        public void callHRMsg(short hr) {
            mHandler.obtainMessage(MESSAGE_UPDATE_HR, hr).sendToTarget();
        }

        @Override
        public void callCUFPREMsg(short cufpre, char err, char type) {
            mHandler.obtainMessage(MESSAGE_UPDATE_CUFPRE, cufpre)
                    .sendToTarget();
        }

        @Override
        public void callLeadOffMsg(String flagOff) {
            // Log.e("STR", "" + flagOff);
            mHandler.obtainMessage(MESSAGE_UPDATE_LeadOff, flagOff)
                    .sendToTarget();
        }

        @Override
        public void callNBPRESULT1Msg(short sbp, short dbp, short abp) {
            nbp_result[0] = sbp;
            nbp_result[1] = dbp;
            nbp_result[2] = abp;
            mHandler.obtainMessage(MESSAGE_UPDATE_NBPRESULT, nbp_result)
                    .sendToTarget();
        }

        @Override
        public void callNBPRESULT2Msg(short pr) {
            // TODO Auto-generated method stub
            Log.e("NIBP", "PR = " + pr);
        }

        @Override
        public void callSpo2PRMsg(short Spo2, short PR, char intensity,
                                  boolean longFlag, boolean dropFlag) {
            // Log.e("SpO2 + PR", ""+Spo2+"+"+PR);
            String tmp ;
            if (Spo2 > 0) {
                tmp = Spo2 + "/" + PR;
            } else {
                tmp = "--/--";
            }
            mHandler.obtainMessage(MESSAGE_UPDATE_SPO2, tmp).sendToTarget();
        }

        @Override
        public void callSpo2WaveMsg(short Spo2Wave, boolean stickFigure,
                                    boolean probeFlag, boolean searchFlag, boolean prSound,
                                    boolean fingerFlag) {
            // TODO Auto-generated method stub
            isFingerOut = fingerFlag;

        }

        @Override
        public void callArrhMsg(short type) {
            // TODO Auto-generated method stub

            // Log.e("Arr", "" + type);
            // Note the difference between the index value and the type.
            // If the type value is 2, the index value of the corresponding display term is 1
            short val = (short) (type - 1);
            real.add(val);
        }

        @Override
        public void callNBPENDMsg(short end) {
            // TODO Auto-generated method stub
            mHandler.obtainMessage(MESSAGE_UPDATE_NBPEND, end).sendToTarget();
        }

        @Override
        public void callNBPERRMsg(short err) {
            // TODO Auto-generated method stub
            if (err > 0 && (err < nbpErrs.length)) {
                mHandler.obtainMessage(MESSAGE_UPDATE_NBPERR, nbpErrs[err])
                        .sendToTarget();
            }
        }

        @Override
        public void callECGENDMsg(short rate) {
            // TODO Auto-generated method stub

            Log.e("Rate", "" + rate);
            // if(rate == 10){
            // serial.ecgAnalyze(Environment.getExternalStorageDirectory() +
            // "/", "data", 0);
            // }
            mHandler.obtainMessage(MESSAGE_UPDATE_ECG_RATE, rate)
                    .sendToTarget();
        }

        @Override
        public void callRRMsg(short rr) {
            // TODO Auto-generated method stub

            Log.e("RR", "" + rr);
        }

        @Override
        public void callAnaEcgMsg(String result) {
            // TODO Auto-generated method stub
            Log.e("CLU", "" + result);
            String[] clus = result.split("@");
            Log.e("CLU", "clus.length = " + clus.length);
            if (clus != null && clus.length == 14) {

                // advice(clus[0]);
                // hr(clus[1]);
                // Pd(clus[2]);
                // PQd(clus[3]);
                // QRSd(clus[4]);
                // Td(clus[5]);
                // QTd(clus[6]);
                // QTcd(clus[7]);
                // PAx(clus[8]);
                // QRSAx(clus[9]);
                // TAx(clus[10]);
                // RV5(clus[11]);
                // SV1(clus[12]);
                // indexs(clus[13]);


                //Combination of real-time arrhythmia prompt and static analysis
                String[] indexs = clus[13].split(";");
                ArrayList<Short> st = new ArrayList<Short>();
                for (String x : indexs) {
                    st.add(Short.parseShort(x));
                }
                ConclusionUtils cls = new ConclusionUtils();
                ArrayList<Short> cmb = cls.combineConclusion(real, st);
                String m = "";
                for (int i = 0; i < cmb.size(); i++) {
                    m = m + ConclusionUtils.chinese[cmb.get(i)];
                    m = m + ";";
                }
                Log.e("CLU", "cmb " + m);
            }
        }

        @Override
        public void callEcgWaveDataMsg(short[] wave) {
            // TODO Auto-generated method stub
/*			
			if (mEcgQueue != null) {
				// Log.e("ECG", "" + mEcgQueue.size());
				for (int i = 48; i < 60; i++) {
					mEcgQueue.offer(wave[i]);
				}
			}
			*/
            for (int i = 48; i < 60; i++) {
                mTempEcgDot[i - 48] = wave[i];
            }
        }

        @Override
        public void callEcgWave7LeadDataMsg(short[] wave) {
            for (int i = 28; i < 35; i++) {
                mTempEcgDot[i - 28] = wave[i];
            }
        }

        @Override
        public void callEcgWavePaceDataMsg(byte[] pace) {
            // TODO Auto-generated method stub
/*			
			if (isEcgPace) {
				String strPace = "";
				for (int i = 0; i < pace.length; i++) {
					strPace += " " + pace[i] + " ";
				}
				Log.e("ECG Pace", strPace);
			}
			*/
            //Avoid drawing jump points and missing marked pacing points.
            // If one signal is pacing signal in each callback, mark the drawing point as pacing point
            boolean isPace = false;
            for (int i = 0; i < pace.length; i++) {
                if (pace[i] == 1) {
                    isPace = true;
                    break;
                }

            }
            if (mEcgQueue != null) {
                if (isPace) {
                    for (int j = 0; j < CHAN; j++) {
                        //Pacing signal, marked as 1.5mV, not processed if it is a straight line
                        if (mTempEcgDot[j] != 0) {
                            mEcgQueue.offer((short) 1230);
                        } else {
                            mEcgQueue.offer(mTempEcgDot[j]);
                        }
                    }
                } else {
                    for (int j = 0; j < CHAN; j++) {
                        mEcgQueue.offer(mTempEcgDot[j]);
                    }
                }
            }
        }

        @Override
        public void callTempMsg(String sTemp) {
            // TODO Auto-generated method stub
            mHandler.obtainMessage(MESSAGE_UPDATE_TEMP, sTemp).sendToTarget();
        }

        @Override
        public void callHBMsg(String hb, String hct, String unit) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callFVCMsg(short fvc, short fev1, short pef, short fef25,
                               short fef75, short fef2575) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callUrineMsg(int[] urine) {
            // TODO Auto-generated method stub
            Log.e("bc401", " " + urine[7] + " " + urine[8]);
        }

        @Override
        public void callBGMsg(String sBG) {
            // TODO Auto-generated method stub
            mHandler.obtainMessage(MESSAGE_UPDATE_BG, sBG).sendToTarget();
        }

        @Override
        public void callUAMsg(String ua, String unit) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callCHOLMsg(String chol, String unit) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callWBCMsg(String wbc) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callBFMsg(String chol, String hdl, String trig, String ldl,
                              String unit) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callOnCallUrineMsg(String leu, String uro, String pro,
                                       String bil, String glu, String asc, String sg, String ket,
                                       String nit, String blo, String ph) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callOnCallUrineMsg2(String cre, String alb) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callGHBMsg(String ngsp, String ifcc, String eag) {
            // TODO Auto-generated method stub

        }

        @Override
        public void callHeightWeightMsg(String weight, String height) {
            if ((Float.parseFloat(weight) > 5.0f)
                    && (Float.parseFloat(height) > 5.0f)) {
                String[] hw = {"" + Float.parseFloat(weight),
                        "" + Float.parseFloat(height)};
                mHandler.obtainMessage(MESSAGE_UPDATE_HW, hw).sendToTarget();
            } else if ((Float.parseFloat(weight) > 0.0f)
                    && (Float.parseFloat(height) == 0.0f)) {
                String[] hw = {"" + Float.parseFloat(weight), "--"};
                mHandler.obtainMessage(MESSAGE_UPDATE_HW, hw).sendToTarget();
            }
        }
    }

    private ConcurrentLinkedQueue<Short> mEcgQueue;
    private short[] mTempEcgDot = new short[12];
    private String[] nbpErrs;// Types of abnormal blood pressure
 	private int type = 0;
    private int CHAN = 12;
    private final int timeLength = 10;
}
